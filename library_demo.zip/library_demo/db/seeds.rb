# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

Quanlymuonsac.create(STT:"1", mahs:"Le Hong Ni", lop:"3B", tensach: "VSAAGN", tacgia: "Thai Quang Sa",
tusach:"thieu nhi", sobm: "1442", ngaymuon: "22/2/2022", ngaytra:"12/12/2022", songay: "2")