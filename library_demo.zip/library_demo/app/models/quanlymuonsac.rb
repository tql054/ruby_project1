class Quanlymuonsac < ApplicationRecord
end
