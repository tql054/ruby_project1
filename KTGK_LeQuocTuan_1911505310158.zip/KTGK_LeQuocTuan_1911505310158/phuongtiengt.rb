class PhuongtienGT
    def initialize(id, hangsx, namsx, dongxe, giaban, bienso, mauxe)
        @id = id
        @hangsx = hangsx
        @namsx = namsx
        @dongxe = dongxe
        @giaban = giaban
        @bienso = bienso
        @mauxe = mauxe
    end

    def gethangsx
        return @hangsx
    end

    def getmauxe
        return @mauxe
    end

    def getbienso
        return @bienso
    end

    def getid
        return @id
    end
end

